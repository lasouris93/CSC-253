﻿/**
* 01SEP2019
* CSC 253
* Grace Ross
* This program also doesn't work. See note below about the foreach statement.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailClassLibrary;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            const int SIZE = 3;

            string[] items = new string[SIZE];

            do
            {
                StandardMessages.DisplayMenu();

                switch (StandardMessages.GetUserInput())
                {
                    case "1":
                        for (int index = 0; index < items.Length; index++)
                        {
                            EnterItem.GetItemInfo();
                        }

                        // I really don't understand why this doesn't work.
                        foreach (RetailItem item in items)
                        {
                            Print.DisplayInput(StandardMessages.DisplayItemInfo(item));
                        }
                        break;
                    case "2":
                        exit = true;
                        break;
                    default:
                        Print.DisplayInput(StandardMessages.DisplayMenuError());
                        break;
                }
            }
            while (exit == false);

            Console.ReadLine();
        }
    }
}
