﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailClassLibrary
{
    public class EnterItem
    {
        public static RetailItem GetItemInfo()
        {
            RetailItem item = new RetailItem();

            Print.DisplayInput("Enter Item's Description: ");
            item.Description = Console.ReadLine();

            Print.DisplayInput("Enter Units On Hand: ");
            item.UnitsOnHand = Console.ReadLine();

            Print.DisplayInput("Enter Price: ");
            item.Price = Console.ReadLine();

            Print.DisplayInput(StandardMessages.DisplayItemInfo(item));

            return item;
        }
    }
}
