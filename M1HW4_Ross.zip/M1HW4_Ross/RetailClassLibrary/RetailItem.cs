﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailClassLibrary
{
    public class RetailItem
    {
        public RetailItem()
        {
            Description = "";
            UnitsOnHand = "";
            Price = "";
        }

        public RetailItem(string description, string unitsOnHand, string price)
        {
            Description = description;
            UnitsOnHand = unitsOnHand;
            Price = price;
        }

        public string Description { get; set; }

        public string UnitsOnHand { get; set; }

        public string Price { get; set; }
    }
}
