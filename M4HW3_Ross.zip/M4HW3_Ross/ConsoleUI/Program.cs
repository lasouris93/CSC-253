﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 07NOV2019
* CSC 253
* Grace Ross
* This program has a TeamLeader class that is derived from the ProductionWorker class. The TeamLeader class has Bonus, RequiredHours, and
*   ActualHours objects to hold the data for the fixed monthly bonus, required training hours, and actual training hours attended. The user
*   can enter data for the shift worked, hourly pay, monthly bonus, required hours, and actual hours. Instances of the objects are then
*   created and displayed.
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            do
            {
                Console.WriteLine("1. Run Program\n2. Exit\nEnter 1 or 2 > ");
                string input = Console.ReadLine();

                switch(input)
                {
                    case "1":
                        GetTeamLeaderInfo();
                        break;
                    case "2":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid input.");
                        break;
                }

            } while (exit == false);
        }

        public static void GetTeamLeaderInfo()
        {
            TeamLeaderLibrary.ProductionWorker workerInfo = new TeamLeaderLibrary.ProductionWorker();
            TeamLeaderLibrary.TeamLeader leaderInfo = new TeamLeaderLibrary.TeamLeader();

            Console.WriteLine("Enter the team leader's shift: ");
            string input = Console.ReadLine();
            workerInfo.Shift = DoIntTryParse(input);

            Console.WriteLine("Enter the team leader's hourly pay: ");
            input = Console.ReadLine();
            workerInfo.Pay = DoDoubleTryParse(input);

            Console.WriteLine("Enter the fixed monthly bonus: ");
            input = Console.ReadLine();
            leaderInfo.Bonus = DoDoubleTryParse(input);

            Console.WriteLine("Enter the required number of training hours for this year: ");
            input = Console.ReadLine();
            leaderInfo.RequiredHours = DoDoubleTryParse(input);

            Console.WriteLine("Enter the actual number of training hours attended this year: ");
            input = Console.ReadLine();
            leaderInfo.ActualHours = DoDoubleTryParse(input);

            // Display the entered data from the instances.
            Console.WriteLine($"Shift: {workerInfo.Shift} | Hourly Pay: ${workerInfo.Pay} | Monthly Bonus: ${leaderInfo.Bonus} | " +
                $"Required Training Hours: {leaderInfo.RequiredHours} | Attended Training Hours: {leaderInfo.ActualHours}");

            // Just added this to display whether the required training hours are met or not.
            if(leaderInfo.ActualHours < leaderInfo.RequiredHours)
            {
                Console.WriteLine("Team leader did not attend the required amount of training hours this year.");
            }
            else
            {
                Console.WriteLine("Team leader attended the required amount of training hours this year.");
            }
        }

        // I kept the Shift variable as an integer datatype.
        public static int DoIntTryParse(string input)
        {
            int output;

            if (int.TryParse(input, out output))
            {
                // Do TryParse for int datatype.
            }
            else
            {
                Console.WriteLine("Invalid input.");
            }

            return output;
        }

        // I made the Pay, Bonus, RequiredHours, and ActualHours variables double datatypes.
        public static double DoDoubleTryParse(string input)
        {
            double output;

            if (double.TryParse(input, out output))
            {
                // Do TryParse for double datatype.
            }
            else
            {
                Console.WriteLine("Invalid input.");
            }

            return output;
        }
    }
}
