﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamLeaderLibrary
{
    public class TeamLeader : ProductionWorker
    {
        public TeamLeader()
        {
            Bonus = 0;
            RequiredHours = 0;
            ActualHours = 0;
        }

        public double Bonus { get; set; }

        public double RequiredHours { get; set; }

        public double ActualHours { get; set; }
    }
}
