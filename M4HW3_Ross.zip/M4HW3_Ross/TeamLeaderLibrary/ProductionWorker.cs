﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamLeaderLibrary
{
    public class ProductionWorker
    {
        public ProductionWorker()
        {
            Shift = 0;
            Pay = 0;
        }

        public int Shift { get; set; }

        // I have Pay as a double datatype instead of a string or int.
        public double Pay { get; set; }
    }
}
