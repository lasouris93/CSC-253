﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class StandardMessages
    {
        public static void DisplayMenu()
        {
            Print.DisplayInput("1. Run Program\n2. Exit\nEnter 1 or 2");
        }

        public static string DisplayMenuError()
        {
            return "Invalid input. Enter 1 or 2.";
        }

        public static string GetUserInput()
        {
            return Console.ReadLine();
        }

        public static string DisplayTryParseError()
        {
            return "Invalid input";
        }
    }
}
