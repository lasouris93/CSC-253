﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class HospitalMethods
    {
        public static double DoTryParse(string input)
        {
            double output;

            if (double.TryParse(input, out output))
            {
                // Do the TryParse
            }
            else
            {
                Print.DisplayInput(StandardMessages.DisplayTryParseError());
            }

            return output;
        }

        public static void GetHospitalCharges()
        {
            double days, medication, surgical, lab, physicalRehab;

            Print.DisplayInput("Days spent in hospital: ");
            string input = Console.ReadLine();
            days = DoTryParse(input);

            Print.DisplayInput("Medication charges: ");
            input = Console.ReadLine();
            medication = DoTryParse(input);

            Print.DisplayInput("Surgical charges: ");
            input = Console.ReadLine();
            surgical = DoTryParse(input);

            Print.DisplayInput("Lab fees: ");
            input = Console.ReadLine();
            lab = DoTryParse(input);

            Print.DisplayInput("Physical rehabilitation charges: ");
            input = Console.ReadLine();
            physicalRehab = DoTryParse(input);
        }

        public static double CalcTotalCharges(double stayCharges, double miscCharges)
        {
            double totalCharges;

            totalCharges = stayCharges + miscCharges;

            return totalCharges;
        }

        public static double CalcMiscCharges(double medication, double surgical, double lab, double physicalRehab)
        {
            double miscCharges;

            miscCharges = medication + surgical + lab + physicalRehab;

            return miscCharges;
        }

        public static double CalcStayCharges(double days)
        {
            double stayCharges;

            const double BASECHARGE = 350;

            stayCharges = BASECHARGE * days;

            return stayCharges;
        }
    }
}
