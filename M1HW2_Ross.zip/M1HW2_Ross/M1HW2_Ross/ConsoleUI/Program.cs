﻿/**
 * 8/27/2019
 * CSC 253
 * Grace Ross
 * This program doesn't work yet. See note below.
 **/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            do
            {
                StandardMessages.DisplayMenu();

                switch (StandardMessages.GetUserInput())
                {
                    case "1":
                        HospitalMethods.GetHospitalCharges();

                        //I remember getting stuck on something similar to this spring semester, but I can't remember how to get unstuck.
                        //Shouldn't this work? I tried using "ref" but that didn't work.
                        Print.DisplayInput($"Total Hospital Charges: {HospitalMethods.CalcTotalCharges(stayCharges, miscCharges)}");
                        break;
                    case "2":
                        exit = true;
                        break;
                    default:
                        Print.DisplayInput(StandardMessages.DisplayMenuError());
                        break;
                }
            }
            while (exit == false);
        }
    }
}
