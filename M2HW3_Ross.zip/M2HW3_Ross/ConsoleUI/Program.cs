﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 15SEP2019
* CSC 253
* Grace Ross
* This program finds the most frequent character in a string that is entered by the user.
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            string input, sentence;

            do
            {
                DisplayMenu();
                input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        Console.WriteLine("Enter a sentence: ");
                        sentence = Console.ReadLine();

                        // An array that holds the characters in the ASCII table.
                        int[] characters = new int[256];
                        // Get the length of the string entered.
                        int length = sentence.Length;
                        // Loop through the string and add the characters to the characters variable.
                        for (int i = 0; i < length; i++)
                        {
                            characters[sentence[i]]++;
                        }

                        // Set the count and the frequent variables
                        int count = -1;
                        char frequent = ' ';
                        // For loop iterates through and finds the maximum count and the most frequent character.
                        for (int i = 0; i < length; i++)
                        {
                            if (count < characters[sentence[i]])
                            {
                                count = characters[sentence[i]];
                                frequent = sentence[i];
                            }
                        }

                        // Display the most frequent character.
                        Console.WriteLine($"Frequent letter: {frequent}");
                        break;
                    case "2":
                        // Exit the program if the user chooses to.
                        exit = true;
                        break;
                    default:
                        // Error message if invalid input is entered.
                        Console.WriteLine("Invalid input. Enter 1 or 2");
                        break;
            }
            }
            while (exit == false);

        }
        public static void DisplayMenu()
        {
            Console.WriteLine("1. Run Program\n2. Exit\nEnter 1 or 2 > ");
        }
    }
}
