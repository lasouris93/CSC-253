﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonClassLibrary
{
    public class CreatePerson
    {
        public static Person EnterPersonInfo()
        {
            Person person = new Person();

            Console.WriteLine("What is your first name? > ");
            string input = Console.ReadLine();
            person.FirstName = input;

            Console.WriteLine("What is your last name? > ");
            input = Console.ReadLine();
            person.LastName = input;

            Console.WriteLine("How old are you? > ");
            input = Console.ReadLine();
            int age = DoTryParse(input);
            person.Age = age;

            return person;
        }

        public static int DoTryParse(string input)
        {
            int output;

            if (int.TryParse(input, out output))
            {
                // Do the TryParse
            }
            else
            {
                Console.WriteLine("Invalid input.");
            }

            return output;
        }
    }
}
