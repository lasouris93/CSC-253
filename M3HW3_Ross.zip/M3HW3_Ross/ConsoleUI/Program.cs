﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PersonClassLibrary;
using System.IO;

/**
* 15OCT2019
* CSC 253
* Grace Ross
* This program has data entered by a user as objects of the Person class. The data from the class is saved to a txt file.
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            // Create a list to add the data to.
            List<Person> persons = new List<Person>();

            do
            {
                DisplayMenu();
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        // Create StreamWriter object.
                        StreamWriter outputFile;

                        // Specify where to save the data.
                        outputFile = File.AppendText("UserInformation.txt");

                        // Add the data to the list.
                        persons.Add(CreatePerson.EnterPersonInfo());

                        foreach (Person person in persons)
                        {
                            // Write the data to the file.
                            outputFile.WriteLine(person.FirstName);
                            outputFile.WriteLine(person.LastName);
                            outputFile.WriteLine(person.Age);
                        }

                        // Close the file.
                        outputFile.Close();

                        // Let the user know where the data has been written to.
                        Console.WriteLine("Data has been written to 'UserInformation.txt'");
                        break;
                    case "2":
                        // Exit the program
                        exit = true;
                        break;
                    default:
                        // Display error message.
                        Console.WriteLine("Invalid input. Enter 1 or 2");
                        break;
                }
            } while (exit == false);
            Console.ReadLine();
        }

        public static void DisplayMenu()
        {
            Console.WriteLine("1. Run program\n2. Exit\nEnter 1 or 2 > ");
        }
    }
}
