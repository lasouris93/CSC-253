﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

/**
* 03OCT2019
* CSC 253
* Grace Ross
* This program reads the RandomNumbers.txt file from M3HW1 and outputs the total of the numbers and the number of random numbers in the file.
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            int numOutput, total = 0;
            StreamReader inputFile;

            // This is where I have RandomNumbers.txt saved.
            inputFile = File.OpenText("D:/Fall 2019/CSC 253 - Advanced C#/Module 3/M3HW1_Ross/ConsoleUI/bin/Debug/RandomNumbers.txt");

            // Reads the file, accumulates the numbers total in the total variable, closes the file, and outputs the total.
            while(!inputFile.EndOfStream)
            {
                numOutput = int.Parse(inputFile.ReadLine());
                total += numOutput;
                
            }
            inputFile.Close();
            Console.WriteLine($"The total of the numbers in the file is {total}.");

            // This is a different way I learned to output information. This uses a StreamReader to read the file line by line. It adds the amount of
            // lines to the counter, closes the file, and then it outputs the amount of numbers based on how many lines are in the file.
            using (StreamReader file = new StreamReader("D:/Fall 2019/CSC 253 - Advanced C#/Module 3/M3HW1_Ross/ConsoleUI/bin/Debug/RandomNumbers.txt"))
            {
                int counter = 0;
                string lines;

                while ((lines = file.ReadLine()) != null)
                {
                    counter++;
                }
                file.Close();
                Console.WriteLine($"The file has {counter} numbers.");
            }
            Console.ReadLine();
        }
    }
}
