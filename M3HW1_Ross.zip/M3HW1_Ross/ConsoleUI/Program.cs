﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO; //This is for the StreamWriter object.

/**
* 01OCT2019
* CSC 253
* Grace Ross
* This program writes a user-specified amount of random numbers to a file.
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            do
            {
                DisplayMenu();
                string input = Console.ReadLine();

                switch(input)
                {
                    case "1":
                        // Get user input for how many numbers to generate.
                        Console.WriteLine("How many numbers do you want generated? > ");
                        input = Console.ReadLine();

                        // Convert the string input to an integer.
                        int numInput = int.Parse(input);

                        // Create the random object.
                        Random rand = new Random();

                        // Create StreamWriter object.
                        StreamWriter outputFile;

                        // Specify where to save the numbers.
                        outputFile = File.AppendText("RandomNumbers.txt");

                        // Display the random number for each iteration up to the number specified by the user.
                        for (int index = 0; index < numInput; index++)
                        {
                            // Limited the range of the numbers up to 100.
                            int numOutput = rand.Next(100);

                            // Write the numbers to the file.
                            outputFile.WriteLine(numOutput);
                        }
                        // Close the file.
                        outputFile.Close();

                        // Let the user know where the numbers were written to.
                        Console.WriteLine("Numbers have been written to 'RandomNumbers.txt'");
                        break;
                    case "2":
                        // Exit the program.
                        exit = true;
                        break;
                    default:
                        // Display error message.
                        Console.WriteLine("Invalid input. Enter 1 or 2");
                        break;
                }
            } while (exit == false);
            Console.ReadLine();
        }

        public static void DisplayMenu()
        {
            Console.WriteLine("1. Run program\n2. Exit\nEnter 1 or 2 > ");
        }
    }
}
