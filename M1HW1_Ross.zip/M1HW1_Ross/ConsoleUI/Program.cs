﻿/**
 * 8/25/2019
 * CSC 253
 * Grace Ross
 * This program works, but my math is wrong. I wrote a note in the PopulationMethods Class.
 **/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;


namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            do
            {
                StandardMessages.DisplayMenu();

                switch (StandardMessages.GetUserInput())
                {
                    case "1":
                        PopulationMethods.GetPopulation();
                        break;
                    case "2":
                        exit = true;
                        break;
                    default:
                        Print.DisplayInput(StandardMessages.DisplayMenuError());
                        break;
                }
            }
            while (exit == false);
            

        }
    }
}
