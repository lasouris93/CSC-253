﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class PopulationMethods
    {
        public static double DoTryParse(string input)
        {
            double output;

            if (double.TryParse(input, out output))
            {
                // Do the TryParse
            }
            else
            {
                Print.DisplayInput(StandardMessages.DisplayTryParseError());
            }

            return output;
        }

        public static void GetPopulation()
        {
            double days, organisms, dailyIncrease, dailyPopulation = 0, population = 0, approximate = 0, conversion = 0.01;

            Print.DisplayInput("Starting number of organisms: ");
            string input = Console.ReadLine();
            organisms = DoTryParse(input);

            Print.DisplayInput("Average daily increase (ex: 10 for 10%): ");
            input = Console.ReadLine();
            dailyIncrease = DoTryParse(input);

            Print.DisplayInput("Number of days to multiply: ");
            input = Console.ReadLine();
            days = DoTryParse(input);

            Print.DisplayInput($"Day\tApproximate Population");
            Print.DisplayInput($"1\t{organisms}");

            //This program works, but my math is off. I got a little frustrated because I feel like I'm pretty close.
            //I have the "approximate" variable to hold the daily population and to increase each iteration, but something's not right.
            for (int index = 1; index < days; index++)
            {
                dailyPopulation = organisms * (dailyIncrease*conversion);
                population = dailyPopulation + organisms;
                approximate += population;
                
                Console.WriteLine($"{index+1}\t{approximate}");
            }
        }
    }
}
