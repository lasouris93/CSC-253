﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 17SEP2019
* CSC 253
* Grace Ross
* This program is supposed to have the user enter a sentence that has no spaces, but
*   capitalized words where the spaces are supposed to be. So far, I've only been able
*   to display a sentence each iteration in the for loop with a space before the word 
*   on that iteration. Or I display the sentence with only a space before the last 
*   capitalized word.
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            do
            {
                DisplayMenu();
                string input = Console.ReadLine();

                switch(input)
                {
                    case "1":
                        Console.WriteLine("Enter a sentence that doesn't have spaces, but the words are capitalized: ");
                        string sentence = Console.ReadLine();

                        // This displays a sentence for each word, and puts a space between the word on that iteration
                        //      and the word before it. I thought I could have the variable addSpace hold the iterations,
                        //      to display the sentence string properly, but I couldn't figure it out.
                        string addSpace = " ";
                        for (int index = 0; index < sentence.Length; index++)
                        {
                            if (char.IsUpper(sentence[index]))
                            {
                                int position = sentence.IndexOf(sentence[index]);

                                addSpace = sentence.Insert(position, " ");

                                Console.WriteLine(addSpace);
                            }
                        }
                        // Displaying this only puts a space between the last capitalized word and the word before it.
                        //Console.WriteLine(sentences);
                        break;
                    case "2":
                        // Exit from the program.
                        exit = true;
                        break;
                    default:
                        // Displays an error message if invalid input is entered.
                        Console.WriteLine("Invalid input. Enter 1 or 2");
                        break;
                }

            } while (exit == false);
        }

        // Display the menu.
        public static void DisplayMenu()
        {
            Console.WriteLine("1. Run program\n2. Exit\nEnter 1 or 2 > ");
        }
    }
}
