﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 010SEP2019
* CSC 253
* Grace Ross
* This program has the user enter a sentence and not only outputs the number of words in the string inputted by tokenizing
*   but also outputs the average number of letters in each word using the char datatype and a testing method of it.
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            do
            {
                DisplayMenu();
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        string sentence;

                        Console.WriteLine("Enter a sentence: ");
                        sentence = Console.ReadLine();

                        // ** Modification **
                        // Run the method to get the word count and average number of letters per word
                        GetWordCountAndAvgLetters(sentence);
                        break;
                    case "2":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid input. Enter 1 or 2 > ");
                        break;
                }
            }
            while (exit == false);

            Console.ReadLine();
        }

        // Method that gets the word count of the sentence. For every string in between tokens, add to the words variable.
        // ** Modification: Find the average number of letters in each word. **
        public static void GetWordCountAndAvgLetters(String sentence)
        {
            int words = 0, letters = 0, averageLetters;
            
            string[] tokens = sentence.Split(null);

            // Find the number of words in the string.
            foreach (string s in tokens)
            {
                ++words;
            }

            // ** Modification **
            // Find the number of white spaces and subtract them from the letters variable.
            foreach (char letter in sentence)
            {
                ++letters;
                if (char.IsWhiteSpace(letter))
                {
                    -- letters;
                }
            }

            // ** Modification **
            // Find the average number of letters in each word.
            averageLetters = letters / words;

            // Display results
            Console.WriteLine($"Number of words in the sentence: {words}\n" +
                $"Average number of letters per word: {averageLetters}");
        }

        // Method to display the menu
        public static void DisplayMenu()
        {
            Console.WriteLine("1. Run Program\n2. Exit\nEnter 1 or 2 > ");
        }
    }
}
