﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 12SEP2019
* CSC 253
* Grace Ross & Nick Zwan
* This program *TODO: ADD PROGRAM DESCRIPTION*
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            GameLibrary.StartGameController.StartGame();
        }
    }
}
