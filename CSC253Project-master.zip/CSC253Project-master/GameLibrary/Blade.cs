﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameLibrary
{
    public class Blade //First weapon(starter) for game. 
    {
        private int _attackPower;
        private int _durability;
        private string _name;
        private string _type;
        public Blade()
        {
            AttackPower = 0;
            Durability = 0;
            Name = "null";
            Type = "null";
        }
        public Blade(int attackPower, int durability, string name, string type)
        {
            AttackPower = attackPower;
            Durability = durability;
            Name = name;
            Type = type;
        }

        public int AttackPower
        {
            get
            {
                return _attackPower;
            }
            set
            {
                _attackPower = value;
            }
        }

        public int Durability
        {
            get
            {
                return _durability;
            }
            set
            {
                _durability = value;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public string Type
        {
            get
            {
                return _type;
            }
            set
            {
                _type = value;
            }

        }
    }
}