﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameLibrary
{
    public class Warrior
    {
        //Used for player class assignment in rooms
        public Warrior()
        {
            Name = null;
            AttackPoints = 0;
            HealthPoints = 0;
            Type = null;
        }

        public Warrior(string name, int attackPoints, int healthPoints, int ac, string type)
        {
            Name = name;
            AttackPoints = attackPoints;
            HealthPoints = healthPoints;
            Type = type;
        }


        public string Name { get; set; }
        public int AttackPoints { get; set; }
        public int HealthPoints { get; set; }
        public string Type { get; set; }
    }
}
