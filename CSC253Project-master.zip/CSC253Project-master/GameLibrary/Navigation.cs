﻿using System;
using System.Collections.Generic;
using System.Text;
using GameLibrary;

namespace GameLibrary
{
    public class Navigation
    {
        
        public static void navigate()
        {

            bool exit = false;


            // The four arrays
            string[] rooms = { "courtyard", "foyer", "hall", "library", "ballroom", "kitchen", "Rest Area", "Boss Lair", " Final Room" };
            string[] weapons = { "knife", "lead pipe", "wrench", "candlestick" };

            // The two lists
            List<string> items = new List<string>();
            List<string> mobs = new List<string>();
            
           


            int currentLocation = 0;
            do
            {
                
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        Console.WriteLine("You have entered the " + rooms[currentLocation] + "...");
                        // Display the rooms array
                        //Console.WriteLine(rooms[currentLocation]);
                        Console.WriteLine("Enter n to go north or s to go south > ");
                        input = Console.ReadLine();


                        // EVENTUALLY MOVE TO ANOTHER METHOD ONCE ^ THAT PART ^ IS FIGURED OUT
                        // WITHOUT USING A LOT OF IF-ELSE STATEMENTS
                        if (input == "n")//Move up one Subscript in the room array.
                        {
                            currentLocation += 1;

                            Console.WriteLine(rooms[currentLocation]);
                            Goblin goblin = new Goblin();
                            goblin.Name = "Goblin the Defiler";
                            goblin.AttackPoints = 10;
                            goblin.Type = "enemy";
                            goblin.HealthPoints = 10;

                            Player player1 = new Player();
                            player1.Name = "Adventurer";
                            player1.HealthPoints = 100;
                            player1.AttackPoints = 100;

                            Blade shortsword = new Blade();
                            shortsword.AttackPower = 10;
                            shortsword.Durability = 10;
                            shortsword.Name = "Short Sword";
                            shortsword.Type = "Bladed weapon";

                            Blade longsword = new Blade();
                            longsword.AttackPower = 20;
                            longsword.Durability = 20;
                            longsword.Name = "Long Sword";
                            longsword.Type = "Long Bladed Weapon";

                            Blade MagicSword = new Blade();
                            longsword.AttackPower = 11000;
                            longsword.Durability = 110000;
                            longsword.Name = "The Final Blade";
                            longsword.Type = "Long Bladed Magic Weapon";

                            Zombie zombie = new Zombie();
                            zombie.Name = "Undead Head-Yanker";
                            zombie.HealthPoints = 20;
                            zombie.AttackPoints = 10;

                            Wolf wolf = new Wolf();
                            wolf.Name = "Rabid wolf";
                            wolf.HealthPoints = 10;
                            wolf.AttackPoints = 5;

                            Wolf wolf2 = new Wolf();
                            wolf.Name = "Feral beast wolf";
                            wolf.HealthPoints = 10;
                            wolf.AttackPoints = 10;

                            Thief thief = new Thief();
                            thief.Name = "Pillager";
                            thief.HealthPoints = 30;
                            thief.Type = "Humanoid";
                            thief.AttackPoints = 10;

                            Warrior Rival = new Warrior();
                            Rival.Name = "Dark Rival";
                            Rival.AttackPoints = 1000;
                            Rival.HealthPoints = 20;
                            Rival.Type = "Humanoid";

                            Mage sorcerer = new Mage();
                            sorcerer.Name = "Sorcerer";
                            sorcerer.AttackPoints = 20;
                            sorcerer.HealthPoints = 20;
                            sorcerer.Type = "Mutated by magic";

                            Troll troll = new Troll();
                            troll.Name = "Cave Troll";
                            troll.AttackPoints = 40;
                            troll.HealthPoints = 20;
                            troll.Type = "Stupid but deadly";


                            //Console.WriteLine("You currently possess " + player1.HealthPoints + " health points");


                            GameClasses.Room room1 = new GameClasses.Room();




                            if (currentLocation == 1)
                            {

                                Console.WriteLine("You have encountered an " + zombie.Name + " his strength is " + "\n"
                                    + goblin.AttackPoints + " and he posseses " + zombie.HealthPoints + " of health.");
                                Console.WriteLine("Will you engage the enemy or just look at him and move on?");
                                Console.ForegroundColor = ConsoleColor.Yellow;
                                Console.WriteLine("1: Attack Zombie, 2: Look and move on. 3: Look around Room.");
                                input = Console.ReadLine();
                                if (input == "1")
                                {
                                    if (player1.AttackPoints > zombie.AttackPoints)
                                    {
                                        Console.ForegroundColor = ConsoleColor.Red;
                                        player1.HealthPoints = player1.HealthPoints - zombie.AttackPoints * 2;
                                        Console.WriteLine("You swing your " + weapons[1] + " at " + zombie.Name + "\n"
                                            + "He strikes back! and disables your left arm." + "\n" + "You counter with a square strike!!" +
                                            "\n" + StandardMessages.killEnemy() + " You walk away with yellow blood falling from your " + weapons[1] + "\n" +
                                            "As you see the claw marks on your chest," + "\n" + "You realize this is only the beginning");
                                        Console.WriteLine("Your encounter has left you gravely injured with " + player1.HealthPoints + " Health points" + "\n");
                                        Console.WriteLine("You see a " + shortsword.Name + " laying in the remains of your enemy"
                                            + "\n" + "You pick it up and carry on the good fight");

                                        player1.AttackPoints = player1.AttackPoints + shortsword.AttackPower;

                                        StandardMessages.useHealthPotion();
                                        player1.HealthPoints = player1.HealthPoints + 20;
                                    }
                                }
                                if (input == "2")
                                {

                                    Console.WriteLine("You stare intently at " + zombie.Name + " and see that his strength comes into" + "\n"
                                        + "focus. ");
                                    Console.WriteLine("Name:" + zombie.Name);
                                    Console.WriteLine("Type:" + zombie.Type);
                                    Console.WriteLine("Health:" + zombie.HealthPoints);
                                    Console.WriteLine("Attack Power:" + zombie.AttackPoints);

                                    Console.WriteLine("Best to leave him be for now. Time to move on...");
                                }
                                else if (input == "3")
                                {

                                    Console.WriteLine("You look around the dimly lit " + rooms[1] + " as your gaze passes over the goblin that occupies the room." +
                                        "\n" + "You see a small dog wandering around and cannot resist the urge to pet him." + "\n" +
                                        "That was a nice escape from your current reality.... Time to move on.");
                                }

                            }
                            if (currentLocation == 2)
                            {
                                Console.WriteLine("You have encountered an " + goblin.Type + " known as " + goblin.Name + " his power is " + "\n"
                                   + goblin.AttackPoints + " and he posseses " + goblin.HealthPoints + " of health.");
                                Console.WriteLine("Will you engage the enemy or just look at him and move on?");
                                Console.ForegroundColor = ConsoleColor.Yellow;
                                Console.WriteLine("1: Engage, 2: Look and move on. 3: Look around Room.");
                                input = Console.ReadLine();
                                if (input == "1")
                                {
                                    if (player1.AttackPoints > goblin.AttackPoints)
                                    {
                                        Console.ForegroundColor = ConsoleColor.Red;
                                        player1.HealthPoints = player1.HealthPoints - goblin.AttackPoints;
                                        Console.WriteLine("You swing your " + shortsword.Name + " at " + goblin.Name + "\n"
                                            + "He dodges and strikes back!" + "\n" + "You counter with a Vorpal strike! " +
                                            "\n" + StandardMessages.killEnemy() + " You walk away with blue blood falling from your " + shortsword.Name);
                                        Console.WriteLine("Your encounter has left you with " + player1.HealthPoints + " Health points");
                                    }
                                }
                                if (input == "2")
                                {

                                    Console.WriteLine("You stare intently at " + goblin.Name + " and see that his strength comes into" + "\n"
                                        + "focus. ");
                                    Console.WriteLine("Name:" + goblin.Name);
                                    Console.WriteLine("Type:" + goblin.Type);
                                    Console.WriteLine("Health:" + goblin.HealthPoints);
                                    Console.WriteLine("Attack Power:" + goblin.AttackPoints);

                                    Console.WriteLine("Best to leave him be for now. Time to move on...");
                                }
                                else if (input == "3")
                                {

                                    Console.WriteLine("You look around the dimly lit " + rooms[1] + " as your gaze passes over the goblin that occupies the room." +
                                        "\n" + "You see a small cat wandering around and cannot resist the urge to pet him." + "\n" +
                                        "That was a nice escape from your current reality.... Time to move on.");
                                }
                            }
                            if (currentLocation == 3)
                            {

                                Console.WriteLine("You have encountered an " + wolf.Name + " their collective strength is " + "\n"
                                    + wolf.AttackPoints + wolf2.AttackPoints + " and they posseses " + wolf.HealthPoints + wolf2.HealthPoints + " of health.");
                                Console.WriteLine("Will you engage them or just look at him and move on?");
                                Console.ForegroundColor = ConsoleColor.Yellow;
                                Console.WriteLine("1: Attack Beasts. 2: Look and move on. 3: Look around Room.");
                                input = Console.ReadLine();
                                if (input == "1")
                                {
                                    if (player1.AttackPoints > wolf.HealthPoints)
                                    {
                                        Console.ForegroundColor = ConsoleColor.Red;
                                        player1.HealthPoints = player1.HealthPoints - wolf.AttackPoints * 2;
                                        Console.WriteLine("You swing your " + shortsword.Name + " at " + wolf.Name + "\n"
                                            + "He bites but you dodge!" + "\n" + "You counter with a cross cut!! The " + wolf.Name + "falls." + "\n" +
                                            "The infuriated " + wolf2.Name + " strikes! You side step and impale him as you fall to the ground!" +
                                            "\n" + StandardMessages.killEnemy() + " You walk away with red blood falling from your " + shortsword.Name + "\n" +
                                            "......" + "\n" + "You hate hurting animals but this was life or death.....");
                                        Console.WriteLine("Your encounter has left you with " + player1.HealthPoints + " Health points" + "\n");
                                        Console.WriteLine("You see a " + longsword.Name + " laying in the remains of your enemies. " + "\n" +
                                            "You toss aside the " + shortsword.Name + " and pick up the " + longsword.Name
                                            + "\n" + "You pick it up and soldier on.");

                                        player1.AttackPoints = player1.AttackPoints - shortsword.AttackPower;
                                        player1.AttackPoints = player1.AttackPoints + longsword.AttackPower;
                                    }
                                }
                                if (input == "2")
                                {

                                    Console.WriteLine("You stare intently at " + wolf.Name + " and " + wolf2.Name + " and see that his strength comes into" + "\n"
                                        + "focus. ");
                                    Console.WriteLine("Name:" + wolf.Name + wolf2.Name);
                                    Console.WriteLine("Type:" + wolf.Type);
                                    Console.WriteLine("Health:" + wolf.HealthPoints + wolf2.HealthPoints);
                                    Console.WriteLine("Attack Power:" + wolf.AttackPoints + wolf2.AttackPoints);

                                    Console.WriteLine("Best to leave them be for now. Time to move on...");
                                }
                                else if (input == "3")
                                {

                                    Console.WriteLine("You look around the " + rooms[1] + " as your gaze passes over the wolves that occupies the room." +
                                        "\n" + "You see a rat crawl pas you and into the drain." + "\n" +
                                        " Time to move on.");
                                }
                            }
                            if (currentLocation == 4)
                            {
                                Console.WriteLine("You have encountered the " + thief.Name + " her strength is " + "\n"
                                    + thief.AttackPoints + " and she posseses " + thief.HealthPoints + " of health.");
                                Console.WriteLine("Will you engage her or just look at him and move on?");
                                Console.ForegroundColor = ConsoleColor.Yellow;
                                Console.WriteLine("1: Attack Pillager. 2: Look and move on. 3: Look around Room.");
                                input = Console.ReadLine();
                                if (input == "1")
                                {
                                    if (player1.AttackPoints > thief.HealthPoints)
                                    {
                                        Console.ForegroundColor = ConsoleColor.Red;
                                        player1.HealthPoints = player1.HealthPoints - thief.AttackPoints * 2;
                                        Console.WriteLine("You swing your " + longsword.Name + " at " + thief.Name + "\n"
                                            + "She snags your pouch with her knife and begins to run!" + "\n" + "You quickly snatch it back!! The " + thief.Name + "lunges." + "\n" +
                                            "but you dodge! " + thief.Name + " strikes! You flip in midair and hit her with the pommel of your blade as you fall to the ground!" + "\n" +
                                            "Something about this girl makes you show mercy. You carry on leaving her there unconcious.");

                                        Console.WriteLine("Your encounter has left you with " + player1.HealthPoints + " Health points" + "\n");
                                    }
                                }
                                if (input == "2")
                                {
                                    Console.WriteLine("You stare intently at " + thief.Name + " and " + thief.Name + " and see that his strength comes into" + "\n"
                                        + "focus. ");
                                    Console.WriteLine("Name:" + thief.Name); ;
                                    Console.WriteLine("Type:" + thief.Type);
                                    Console.WriteLine("Health:" + thief.HealthPoints);
                                    Console.WriteLine("Attack Power:" + thief.AttackPoints);

                                    Console.WriteLine("Best to sneak around her sticky fingers....");
                                }
                                else if (input == "3")
                                {

                                    Console.WriteLine("You look around the " + rooms[4] + " as your gaze passes over the pillager girl that occupies the room." +
                                        "\n" + "You see much gold on the ground. Why bother? " + "\n" +
                                        " Time to move on.");
                                }
                            }
                            if (currentLocation == 5)
                            {

                                Console.WriteLine("You have encountered an " + sorcerer.Name + " his collective magical ability is " + "\n"
                                    + sorcerer.AttackPoints + " and he posseses " + sorcerer.HealthPoints + " of health.");
                                Console.WriteLine("Will you engage the mage or just look at him and move on?");
                                Console.ForegroundColor = ConsoleColor.Yellow;
                                Console.WriteLine("1: Engage Mage. 2: Look and move on. 3: Look around Room.");
                                input = Console.ReadLine();
                                if (input == "1")
                                {
                                    if (player1.AttackPoints > sorcerer.HealthPoints)
                                    {
                                        Console.ForegroundColor = ConsoleColor.Red;
                                        player1.HealthPoints = player1.HealthPoints - sorcerer.AttackPoints * 2;
                                        Console.WriteLine("You swing your " + longsword.Name + " at " + sorcerer.Name + "\n"
                                            + "He puts up a magical shield and blocks you." + "\n" + "You recoil and roll, spinning and slashing! The " + sorcerer.Name + "s head rolls." + "\n" +
                                            "\n" + StandardMessages.killEnemy() + " You walk away with red blood falling from your " + longsword.Name + "\n" +
                                            "......");
                                        Console.WriteLine("Your encounter has left you with " + player1.HealthPoints + " Health points" + "\n");
                                    }
                                }
                                if (input == "2")
                                {

                                    Console.WriteLine("You stare intently at " + sorcerer.Name + " and " + sorcerer.Name + " and see that his power comes into" + "\n"
                                        + "focus. ");
                                    Console.WriteLine("Name:" + sorcerer.Name);
                                    Console.WriteLine("Type:" + sorcerer.Type);
                                    Console.WriteLine("Health:" + sorcerer.HealthPoints);
                                    Console.WriteLine("Attack Power:" + sorcerer.AttackPoints);

                                    Console.WriteLine("Magic isnt your thing.... Time to move on.");
                                }
                                else if (input == "3")
                                {
                                    Console.WriteLine("You look around the " + rooms[5] + " as your gaze passes over the sorcerer that occupies the room." +
                                        "\n" + "You see a rat crawl past you and into the drain." + "\n" +
                                        " Time to move on.");
                                }
                            }
                            if (currentLocation == 6)
                            {
                                StandardMessages.restAreaMessage();
                            }
                            if (currentLocation == 7)
                            {

                                Console.WriteLine("You have come face to face with your " + Rival.Name + ". His collective magical ability is " + "\n"
                                    + Rival.AttackPoints + " and he posseses " + Rival.HealthPoints + " of health."); ;
                                Console.WriteLine("Will you engage your enemy or just look at him and move on?");
                                Console.ForegroundColor = ConsoleColor.Yellow;
                                Console.WriteLine("1: Engage Rival. 2: Look and move on. 3: Look around Room.");
                                input = Console.ReadLine();
                                if (input == "1")
                                {
                                    if (player1.AttackPoints >= Rival.HealthPoints)
                                    {
                                        Console.ForegroundColor = ConsoleColor.Red;
                                        player1.HealthPoints = player1.HealthPoints - sorcerer.AttackPoints * 2;
                                        Console.WriteLine("You swing your " + MagicSword.Name + " at " + Rival.Name + "\n"
                                            + "but he counters." + "\n" + "You recoil and roll, spinning and slashing! The " + Rival.Name + "seems to be able to " +
                                              "\n" + "predict your every move. He attacks and defends in perfect synchrony with you as if he were your twin." +
                                             "You come to understand what this is.... This enemy is you. To win....... you have to lose......." + "\n" +
                                             " You initiate a vorpal strike and see your dark twin do the same..... You impale each other but he vanishes and you fall...." +
                                            "\n" + StandardMessages.killEnemy() + " You crawl away leaving a trail of blood, leaving your " + MagicSword.Name + " behind." + "\n");
                                            
                                        Console.WriteLine("Your encounter has left you with " + (player1.HealthPoints - player1.HealthPoints) + 1 + " Health points" + "\n");
                                    }
                                }
                                if (input == "2")
                                {

                                    Console.WriteLine("You stare intently at " + Rival.Name + " and see that his power comes into" + "\n"
                                        + "focus. ");
                                    Console.WriteLine("Name:" + Rival.Name);
                                    Console.WriteLine("Type:" + Rival.Type);
                                    Console.WriteLine("Health:" + Rival.HealthPoints);
                                    Console.WriteLine("Attack Power:" + Rival.AttackPoints);

                                    Console.WriteLine("This battle isnt optional, youll have to fight eventually.... Time to move on.");
                                }
                                else if (input == "3")
                                {
                                    Console.WriteLine("You look around the " + rooms[6] + " as your gaze passes over the figure that occupies the room." +
                                        "\n" + "You get a strange sense of forboding." + "\n" +
                                        " Time to move on.");
                                }
                                
                            }
                            if (currentLocation == 8)
                            {
                                StandardMessages.victoryMessage();
                                Console.WriteLine();
                                
                            }
                            if (currentLocation == 9)
                            {
                                System.Environment.Exit(0);
                            }

                            if (input == "s")//Move down one Subscript in room arrray.

                                if (currentLocation <= 0)
                                {
                                    Console.WriteLine("You can't go that way!");
                                }
                                else
                                {
                                    currentLocation -= 1;
                                    Console.WriteLine(rooms[currentLocation]);

                                }
                        }
                        break;
                    case "2":
                        {
                            StandardMessages.displayPotions();
                        }
                        break;
                    case "3":
                        {
                            StandardMessages.displayTreasures();
                        }
                        break;
                    case "4":
                        {
                            StandardMessages.displayWeapons();
                        }
                        break;
                    case "5":
                        exit = true;
                        break;
                    case "help":
                        StandardMessages.DisplayHelpMenu();
                        break;
                    default:
                        StandardMessages.invalidEntry();
                        break;
                }
                
                

            } while (exit == false);
  
            
        }
      

    }
}


    

    


