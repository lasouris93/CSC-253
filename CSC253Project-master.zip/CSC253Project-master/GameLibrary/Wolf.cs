﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameLibrary
{
   
        public class Wolf //third enemy for game.
        {
            private int _attackPoints;
            private int _healthPoints;
            private string _name;
            private string _type;


            public Wolf()
            {
                AttackPoints = 0;
                HealthPoints = 0;
                Name = "null.";
                Type = "null";
            }
            public Wolf(int attackPoints, int healthPoints, string name, string type)
            {
                AttackPoints = attackPoints;
                HealthPoints = healthPoints;
                Name = name;
            }

            public int AttackPoints
            {
                get
                {
                    return _attackPoints;
                }
                set
                {
                    _attackPoints = value;
                }
            }

            public int HealthPoints
            {
                get
                {
                    return _healthPoints;
                }
                set
                {
                    _healthPoints = value;
                }
            }

            public string Name
            {
                get
                {
                    return _name;
                }
                set
                {
                    _name = value;
                }
            }

            public string Type
            {
                get
                {
                    return _type;
                }
                set
                {
                    _type = value;
                }
            }

        }
    }
