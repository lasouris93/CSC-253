﻿using System;

namespace GameLibrary
{
    //This contains the classes needed to program the first iteration.

    namespace GameClasses

    {
        public class Room //Not sure if this is needed yet but is created for class room.
        {

            private int _location;
            private string _color;
            private string _loot;
            private string _name;

            public Room()
            {
                Location = 0;
                Color = null;
                Loot = null;
                Name = null;

            }

            public Room(int location, string color, string loot, string name)
            {
                Location = location;
                Color = color;
                Loot = loot;
                Name = name;
                
            }
            public int Location
            {
                get
                {
                    return _location;
                }
                set
                {
                    _location = value;
                }
            }

            public string Color
            {
                get
                {
                    return _color;
                }
                set
                {
                    _color = value;
                }
            }

            public string Loot
            {
                get
                {
                    return _loot;
                }
                set
                {
                    _loot = value;
                }
            }

            public string Name
            {
                get
                {
                    return _name;
                }
                set
                {
                    _name = value;
                }
            }
        }
    }
}



        

    
