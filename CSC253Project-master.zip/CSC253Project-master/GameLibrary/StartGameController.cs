﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameLibrary
{
    public class StartGameController
    {
        string input = Console.ReadLine();
        public static void StartGame()
        {
            StandardMessages.passwordRequest();
            //StandardMessages.welcome();  
            Navigation.navigate();
        }
    }
}




