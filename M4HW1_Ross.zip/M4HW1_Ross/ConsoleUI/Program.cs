﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 01NOV2019
* CSC 253
* Grace Ross
* Well, I finally figured this one out. Somehow, by completing M4HW2, I saw how I could get this one to work as it should. I definitely
*   overthought when it came to writing this program. Having the user enter the data is what caused me to overcomplicate this. Employee is
*   the base class, and ProductionWorker is the derived one. The shift variable is an integer datatype, and I have the Pay variable as a
*   double datatype because that makes more sense to me than having it as a string.The user may enter an employee's name, ID number, shift, 
*   and hourly pay, and all will display to the screen.
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            string input;

            do
            {
                Console.WriteLine("1. Run Program\n2. Exit\nEnter 1 or 2 > ");
                input = Console.ReadLine();

                switch(input)
                {
                    case "1":
                        GetEmployeeInfo();
                        break;
                    case "2":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid input. Enter 1 or 2");
                        break;
                }

            } while (exit == false);

            Console.ReadLine();
        }

        // The user can enter info about the employee.
        public static void GetEmployeeInfo()
        {
            EmployeeLibrary.Employee employeeInfo = new EmployeeLibrary.Employee();
            EmployeeLibrary.ProductionWorker workerInfo = new EmployeeLibrary.ProductionWorker();

            Console.WriteLine("Enter the employee's name: ");
            employeeInfo.Name = Console.ReadLine();

            Console.WriteLine("Enter the employee's ID number: ");
            employeeInfo.Number = Console.ReadLine();

            Console.WriteLine("Enter the employee's shift: ");
            string input = Console.ReadLine();
            workerInfo.Shift = DoIntTryParse(input);

            Console.WriteLine("Enter the employee's hourly pay: ");
            input = Console.ReadLine();
            workerInfo.Pay = DoDoubleTryParse(input);

            // Display the entered data from the instances.
            Console.WriteLine($"Employee Name: {employeeInfo.Name} | Employee ID: {employeeInfo.Number} | Shift: {workerInfo.Shift} | Hourly Pay: ${workerInfo.Pay}");
        }
        public static int DoIntTryParse(string input)
        {
            int output;

            if (int.TryParse(input, out output))
            {
                // Do TryParse for int datatype.
            }
            else
            {
                Console.WriteLine("Invalid input.");
            }

            return output;
        }

        public static double DoDoubleTryParse(string input)
        {
            double output;

            if(double.TryParse(input, out output))
            {
                // Do TryParse for double datatype.
            }
            else
            {
                Console.WriteLine("Invalid input.");
            }

            return output;
        }
    }
}
