﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 08SEP2019
* CSC 253
* Grace Ross
* This program has the user enter a sentence and outputs the number of words in the string inputted by tokenizing.
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            do
            {
                DisplayMenu();
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        string sentence;

                        Console.WriteLine("Enter a sentence: ");
                        sentence = Console.ReadLine();

                        // Run the method to get the word count and display it
                        GetWordCount(sentence);

                        Console.ReadLine();
                        break;
                    case "2":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid input. Enter 1 or 2 > ");
                        break;
                }
            }
            while (exit == false);
        }

        // Method that gets the word count of the sentence. For every string in between tokens, add to the words variable.
        public static void GetWordCount(String sentence)
        {
            int words = 0;

            string[] tokens = sentence.Split(null);

            foreach (string s in tokens)
            {
                ++words;
            }

            Console.WriteLine($"Number of words in the sentence: {words}");
        }

        // Method to display the menu
        public static void DisplayMenu()
        {
            Console.WriteLine("1. Run Program\n2. Exit\nEnter 1 or 2 > ");
        }
    }
}
