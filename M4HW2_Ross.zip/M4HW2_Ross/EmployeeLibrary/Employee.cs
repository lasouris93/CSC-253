﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Employee
    {
        public Employee(string name, string number)
        {
            Name = name;
            Number = number;
        }

        public string Name { get; set; }

        public string Number { get; set; }
    }

    public class ShiftSupervisor : Employee 
    {
        public ShiftSupervisor(string name, string number, int salary, int bonus)
                                                             : base(name, number)
        {

            Salary = salary;
            Bonus = bonus;
        }
        public int Salary { get; set; }

        public int Bonus { get; set; }
    }
}
