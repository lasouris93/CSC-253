﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 01NOV2019
* CSC 253
* Grace Ross
* This program has the Employee class as the base class and ShiftSupervisor as the derived class. The data is hardcoded and displays the 
*   instances from Employee and ShiftSupervisor. I think I overthought M4HW1, so I'm going to try that one again. Hardcoding the data is 
*   obviously easier, and having the user enter the data messed me up with the first homework. Following the DemoInheritance helped with 
*   this homework.
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = true;
            do
            {
                Console.WriteLine("1. Run program\n2. Exit\nEnter 1 or 2 > ");
                string input = Console.ReadLine();

                switch(input)
                {
                    case "1":
                        EmployeeLibrary.ShiftSupervisor supervisor = new EmployeeLibrary.ShiftSupervisor("Grace Ross", "0827", 40000, 500);

                        Console.WriteLine($"Employee Name: {supervisor.Name}| Employee ID: {supervisor.Number} | Salary: {supervisor.Salary} | Bonus: {supervisor.Bonus}");
                        break;
                    case "2":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid input.");
                        break;
                }
            } while (exit == false);
            Console.ReadLine();
        }
    }
}
