﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PersonClassLibrary;
using System.IO;

/**
* 16OCT2019
* CSC 253
* Grace Ross
* This program is supposed to read the information from the UserInformation.txt file and load the data into the class named "Person". 
*   It should then display the formatted results.
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            // This below in comments is what I've been trying to figure out. I understand the concept of putting the
            //      data in a list and then referencing the list index to fill the attribute in the class, but I couldn't figure
            //      out how to write it. I used tokenizing to at least produce a result.
            //string line;
            //StreamReader inputFile;

            ////List<Person> persons = new List<Person>();
            
            //while (line = file.ReadLine()) != null)
            //{
            //    //persons.Add(new Person());
            //}
            //inputFile.Close();

            string line;
            StreamReader inputFile;
            List<string> persons = new List<string>();

            inputFile = File.OpenText(@"D:/Fall 2019/CSC 253 - Advanced C#/Module 3/M3HW3_Ross/ConsoleUI/bin/Debug/UserInformation.txt");
            while ((line = inputFile.ReadLine()) != null)
            {
                string[] tokens = line.Split('\n');
                foreach (string s in tokens)
                {
                    Console.WriteLine(s);
                }
            }

            inputFile.Close();

            Console.ReadLine();
        }
    }
}
