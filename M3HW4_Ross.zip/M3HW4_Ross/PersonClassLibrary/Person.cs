﻿using System;

namespace PersonClassLibrary
{
    public class Person
    {
        public Person()
        {
            FirstName = "";
            LastName = "";
            Age = "";
        }

        public Person(string firstName, string lastName, string age)
        {
            FirstName = firstName;
            LastName = lastName;
            Age = age;
        }

        private string _firstName;
        private string _lastName;
        private string _age;

        public string FirstName
        {
            get
            {
                return _firstName;
            }

            set
            {
                _firstName = value;
            }
        }

        public string LastName
        {
            get
            {
                return _lastName;
            }

            set
            {
                _lastName = value;
            }
        }

        public string Age
        {
            get
            {
                return _age;
            }

            set
            {
                _age = value;
            }
        }
    }
}
