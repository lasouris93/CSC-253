﻿/**
* 01SEP2019
* CSC 253
* Grace Ross
* This program doesn't work yet. See note below.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarClassLibrary;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            do
            {
                StandardMessages.DisplayMenu();

                Car car = new Car();

                switch (StandardMessages.GetUserInput())
                {
                    case "1":
                        CreateCar.GetCarInfo();

                        Print.DisplayInput("Would you like to accelerate or brake? Enter a or b: ");
                        string input = Console.ReadLine();
                        
                        //I'm not sure how to implement this part of the program.
                        if (input == "a")
                        {
                            Car.Accelerate(speed);
                        }
                        else if (input == "b")
                        {
                            Car.Brake();
                        }
                        else
                        {
                            Print.DisplayInput(StandardMessages.DisplayTryParseError());
                        }

                        break;
                    case "2":
                        exit = true;
                        break;
                    default:
                        Print.DisplayInput(StandardMessages.DisplayMenuError());
                        break;
                }
            }
            while (exit == false);

            Console.ReadLine();
        }
    }
}
