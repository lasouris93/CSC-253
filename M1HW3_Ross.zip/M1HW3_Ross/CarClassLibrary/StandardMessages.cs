﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarClassLibrary
{
    public class StandardMessages
    {
        public static void DisplayMenu()
        {
            Print.DisplayInput("1. Enter Car Info\n2. Exit\nEnter 1 or 2.");
        }

        public static string DisplayMenuError()
        {
            return "Invalid input. Enter 1 or 2.";
        }

        public static string GetUserInput()
        {
            return Console.ReadLine();
        }

        public static string DisplayCarInfo(Car car)
        {
            return $"Year: {car.Year} | Make: {car.Make} | Speed: {car.Speed} mph";
        }

        public static string DisplayTryParseError()
        {
            return "Invalid input";
        }
    }
}
