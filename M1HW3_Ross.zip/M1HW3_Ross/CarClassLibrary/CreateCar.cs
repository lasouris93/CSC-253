﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarClassLibrary
{
    public class CreateCar
    {
        public static Car GetCarInfo()
        {
            Car car = new Car();

            Print.DisplayInput("Enter Car's Year: ");
            car.Year = Console.ReadLine();

            Print.DisplayInput("Enter Car's Make: ");
            car.Make = Console.ReadLine();

            Print.DisplayInput("Enter the speed of the car: ");
            string input = Console.ReadLine();
            int speedRate = DoTryParse(input);
            car.Speed = speedRate;

            Print.DisplayInput(StandardMessages.DisplayCarInfo(car));

            return car;
        }

        public static int DoTryParse(string input)
        {
            int output;

            if (int.TryParse(input, out output))
            {
                // Do the TryParse
            }
            else
            {
                Print.DisplayInput(StandardMessages.DisplayTryParseError());
            }

            return output;
        }
    }
}
